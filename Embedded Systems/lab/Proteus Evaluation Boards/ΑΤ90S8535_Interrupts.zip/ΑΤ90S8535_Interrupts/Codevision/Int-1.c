#asm
   .equ __lcd_port=0x15 ;PORTC
#endasm
#include <90s8535.h>
#include <stdio.h>   
#include <delay.h>
#include <stdlib.h>   
#include <lcd.h>

int h,m,s;  
char strs[3],strm[3],strh[3]; 

interrupt [EXT_INT0] void ext_int0_isr(void)
{
  h=0;
  m=0;
  s=0;
}

interrupt [EXT_INT1] void ext_int1_isr(void)
{      
       s++;
       if(s==60)
         {
         m++;
         s=0;
         }     
       if(m==60)
         {
         h++;
         m=0;
         }      
       if(h==24) h=0;
       
       itoa(s,strs);
       itoa(m,strm);
       itoa(h,strh);
       lcd_gotoxy(0,0);
       lcd_clear();
       if(h<=9) lcd_putsf("0");
       lcd_puts(strh);
       lcd_putsf(":");
       if(m<=9) lcd_putsf("0");
       lcd_puts(strm);
       lcd_putsf(":");
       if(s<=9) lcd_putsf("0");
       lcd_puts(strs);

       delay_ms(100);  
}

void main(void)
{

UCR=0x18;
UBRR=0x19;
GIMSK=0xC0;
MCUCR=0x03;
GIFR=0xC0;
 
#asm("sei")    
lcd_init(20); 
while (1)
      {
       putsf("\r Waiting ...");
       delay_ms(2000);
      }
}
