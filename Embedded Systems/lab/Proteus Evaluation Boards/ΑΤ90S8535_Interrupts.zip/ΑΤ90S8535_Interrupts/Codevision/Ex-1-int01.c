#include <90s8535.h>
#include <stdlib.h>
#include <alcd.h>
#include <delay.h>
#include <stdio.h>

char str[10];
int i;

interrupt [EXT_INT0] void ext_int0_isr(void)
{


lcd_clear();
lcd_putsf("INT0 active ");
for(i=0;i<15;i++)
  {
  lcd_gotoxy(13,0);
  itoa(i,str);
  lcd_puts(str);
  delay_ms(500);
  }
}

interrupt [EXT_INT1] void ext_int1_isr(void)
{
lcd_clear();
lcd_gotoxy(0,1);
lcd_putsf("INT1 active ");
for(i=0;i<10;i++)
  {
  lcd_gotoxy(13,1);
  itoa(i,str);
  lcd_puts(str);
  delay_ms(500);
  }
}

void main(void)
{

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Low level
// INT1: On
// INT1 Mode: Low level
GIMSK=0xC0;
MCUCR=0x00;
GIFR=0xC0;

// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
// UART Baud Rate: 9600
UCR=0x18;
UBRR=0x19;

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTC Bit 0
// RD - PORTC Bit 1
// EN - PORTC Bit 2
// D4 - PORTC Bit 4
// D5 - PORTC Bit 5
// D6 - PORTC Bit 6
// D7 - PORTC Bit 7
// Characters/line: 20
lcd_init(20);

// Global enable interrupts
#asm("sei")

while (1)
 {
  lcd_clear();
  lcd_putsf("Activate INT0-INT1"); 
  lcd_gotoxy(0,1);     
  for(i=0;i<20;i++)
    {
    lcd_putsf(".");
    delay_ms(500);
    }//for
  }//while
}//main
