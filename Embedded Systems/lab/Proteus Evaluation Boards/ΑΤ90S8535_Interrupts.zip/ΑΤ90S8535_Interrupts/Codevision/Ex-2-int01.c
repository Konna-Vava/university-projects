#asm
   .equ __lcd_port=0x15 ;PORTC
#endasm
#include <90s8535.h>
#include <stdio.h>
#include <delay.h>
#include <lcd.h>

int i=0;

// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
 i=0;
 printf("\r Reset");
}

// External Interrupt 1 service routine
interrupt [EXT_INT1] void ext_int1_isr(void)
{ 
  printf("\n\r Inside Int1");
  #asm("sei")
do{
    printf("\n\r Parameter i=%d",i);
    i++;
    delay_ms(1000);
    }while(i<10);
}

void main(void)
{
 int cnt;

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Low level
// INT1: On
// INT1 Mode: Low level
GIMSK=0xC0;
//MCUCR=0x00; 
MCUCR=0x08;
GIFR=0xC0;

UCR=0x18;
UBRR=0x19;
lcd_init(20);

// Global enable interrupts
#asm("sei")

while (1)
 {
  lcd_clear();
  lcd_putsf("Activate INT0-INT1"); 
  lcd_gotoxy(0,1);     
  for(cnt=0;cnt<20;cnt++)
    {
    lcd_putsf(".");
    delay_ms(500);
    }
  }//while
}//main
