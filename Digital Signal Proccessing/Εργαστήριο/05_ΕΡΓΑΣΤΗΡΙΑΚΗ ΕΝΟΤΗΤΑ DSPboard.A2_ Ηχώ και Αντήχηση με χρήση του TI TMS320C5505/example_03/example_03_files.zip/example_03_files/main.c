/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/* 	 main.c                                                                  */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   TMS320C5515 USB Stick Application 3 Echo and Reverberation.             */
/*   Take microphone input and send to headphones with ring modulation.      */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00	                                                         */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision: 1.00                                                          */
/*   15th September 2010. Created TMS320C5505 USB Stick code.                */
/*                                                                           */
/*****************************************************************************/
/*
 * Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "stdio.h"
#include "usbstk5515.h"
#include "usbstk5515_led.h"
#include "aic3204.h"
#include "PLL.h"
#include "bargraph.h"
#include "oled.h"
#include "pushbuttons.h"
#include "stereo.h"
#include "echo.h"
#include "reverberation.h"

Int16 left_input;
Int16 right_input;
Int16 left_output;
Int16 right_output;
Int16 mono_input;

#define SAMPLES_PER_SECOND 24000L

/* Use 30 for microphone. Use 0 for line */
#define GAIN_IN_dB 30

unsigned long int i = 0;

unsigned int Step = 0; 
unsigned int LastStep = 99;

unsigned int key = 0;


/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  main( )                                                                 *
 *                                                                          *
 * ------------------------------------------------------------------------ */
void main( void ) 
{
    /* Initialize BSL */
    USBSTK5515_init( );
	
	/* Initialize PLL */
	pll_frequency_setup(60);

    /* Initialise hardware interface and I2C for code */
    aic3204_hardware_init();
    
    /* Initialise the AIC3204 codec */
	aic3204_init(); 
	
	/* Turn off the 4 coloured LEDs */
	USBSTK5515_ULED_init();
	
	/* Initialise the OLED LCD display */
	oled_init();
	SAR_init();
    oled_display_message("                 ", "                   ");
    printf("\n\nRunning Project Echo and Reverberation\n");
    printf( "<-> Audio Loopback from Microphone In --> to Headphones/Lineout\n\n" );

	/* Setup sampling frequency and 30dB gain for microphone */
    set_sampling_frequency_and_gain(SAMPLES_PER_SECOND, GAIN_IN_dB);

    oled_display_message("Application 3      ", "Echo and Reverb    ");

	/* New. Add descriptive text */ 
	puts("\n Bargraph at 6dB intervals");
    puts("\n Press SW1 for DOWN, SW2 for UP, SW1 + SW2 for reset\n");
    puts(" Step 1   = Straight through, no signal processing. Set levels");
    puts(" Step 2   = Echo on left Channel");
    puts(" Step 3   = Reverberation on left channel");	
    puts(" Step 4   = Echo on left channel. Reverberation on right channel");
    
	/* New. Default to XF LED off */
	asm(" bclr XF");
    
  
 	for ( i = 0  ; i < SAMPLES_PER_SECOND * 600  ;i++  )
 	{

     aic3204_codec_read(&left_input, &right_input); // Configured for one interrupt per two channels.
   
     mono_input = stereo_to_mono(left_input, right_input);
     
      Step = pushbuttons_read(4);
         
	  if ( Step == 1 )
        {
         if ( Step != LastStep )
          {
           oled_display_message("STEP1 No Processing", "      Set Levels   ");
           LastStep = Step;
          }	
         left_output = left_input;      // Straight trough. No processing.
	     right_output = right_input;
	    } 
	  else if ( Step == 2)
        {
          if ( Step != LastStep)
          {
           oled_display_message("STEP2 Left = Echo  ", "     Right = normal");
           echo_array_clear();
           LastStep = Step;
          }

         left_output = echo(mono_input); // Echo on left channel only.
         right_output = mono_input;           		
 
        } 
      else if ( Step == 3)
        {
          if ( Step != LastStep)
          {
           oled_display_message("STEP3 Left = Reverb", "     Right = normal");
           reverberation_array_clear();
           LastStep = Step;
          }	
          
         left_output = reverberation(mono_input); // Reverberation on left channel only.
         right_output = mono_input;    	

		}  
	  else if ( Step == 4)
	    {
          if ( Step != LastStep)
          {
           oled_display_message("STEP4 Left = Echo  ", "     Right = Reverb");
           echo_array_clear();
           reverberation_array_clear();
           LastStep = Step;
          }		    
	     
          left_output = echo(mono_input);
          right_output = reverberation(mono_input);	      

	    }		  
     aic3204_codec_write(left_output, right_output);

     bargraph_6dB(left_output, right_output);
 	}

   /* Disable I2S and put codec into reset */ 
    aic3204_disable();

    printf( "\n***Program has Terminated***\n" );
    
    oled_display_message("PROGRAM HAS        ", "TERMINATED        ");
    
    SW_BREAKPOINT;
}

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  End of main.c                                                           *
 *                                                                          *
 * ------------------------------------------------------------------------ */
