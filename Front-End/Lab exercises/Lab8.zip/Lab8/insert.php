<html>
	<head>
		<meta charset="UTF-8">	
		<TITLE>Record results!</TITLE>
	</head>
	<body>
		<?php
			include("conn.php");
			$email=$_POST['email'];
			$state=$_POST['state'];
			$comments=$_POST['comments'];
			$sql = "INSERT INTO states (email, state, comments)
			VALUES ('$email', '$state', '$comments');";
			if ($conn->query($sql) === TRUE) {
				echo "New record created successfully!";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}
			$conn->close();	
		?>
		<br>
		<button onclick="goBack()">Go Back</button>	
		<script>
			function goBack() {
			  window.history.back();
			}
		</script>	
	</body>
	
</html>