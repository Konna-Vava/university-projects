<html>
	<head>
		<meta charset="UTF-8">	
		<TITLE>Record results!</TITLE>
	</head>
	<body>
		<?php
		include("conn.php");
		$email=$_GET['email'];
		$sql = "SELECT state, time, comments FROM `states` WHERE `email` = '".$email."';";
		$result = $conn->query($sql);
	
        if (mysqli_num_rows($result) > 0) {
			echo "<table border=1>
					<tr><th>Time</th><th>State</th><th>Comments</th></tr>";
            while($row = mysqli_fetch_assoc($result)) {
              echo "<tr><td>" . $row['time']. "</td><td>" . $row['state']. "</td><td>" . $row['comments']. "</td></tr>";
            }
			echo "</table>";
         } else {
            echo "0 results";
         }

		$conn->close();	
		?>
		<br><button onclick="goBack()">Go Back</button>	
		<script>
			function goBack() {
			  window.history.back();
			}
		</script>	
	</body>
	
</html>