-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 21 Δεκ 2021 στις 16:59:50
-- Έκδοση διακομιστή: 10.1.38-MariaDB
-- Έκδοση PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `my1stdb`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `states`
--

CREATE TABLE `states` (
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(20) NOT NULL,
  `state` varchar(40) NOT NULL,
  `comments` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `states`
--

INSERT INTO `states` (`time`, `email`, `state`, `comments`) VALUES
('2021-12-21 13:12:27', 'mfeidakis@gmail.com', 'xalia', 'etsi'),
('2021-12-21 13:17:43', 'mfeidakis@gmail.com', 'ÎšÎ±Î»ÏÏ„ÎµÏÎ±', 'ÎˆÏ‡ÎµÎ¹ Î®Î»Î¹Î¿'),
('2021-12-21 15:24:50', 'mfeidakis@gmail.com', 'ÎšÎ±Î»Î¬', 'ÎˆÏÏ‡Î¿Î½Ï„Î±Î¹ Î´Î¹Î±ÎºÎ¿Ï€ÎµÏ‚'),
('2021-12-21 15:27:12', 'mfeidakis@gmail.com', 'Ï€Î¿Î»Ï… Ï‡Î±Î»Î¹Î±', 'ÎˆÏÏ‡Î¿Î½Ï„Î±Î¹ Î´Î¹Î±ÎºÎ¿Ï€ÎµÏ‚'),
('2021-12-21 15:35:04', 'm.poly@uniwa.gr', 'ÎšÎ±Î»ÏÏ„ÎµÏÎ±', 'mpla');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `students`
--

CREATE TABLE `students` (
  `Name` varchar(20) NOT NULL,
  `Surname` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Άδειασμα δεδομένων του πίνακα `students`
--

INSERT INTO `students` (`Name`, `Surname`, `email`) VALUES
('Maria', 'Poychronaki', 'm.poly@uniwa.gr'),
('Mike', 'Fee', 'mfeidakis@gmail.com');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`time`,`email`),
  ADD KEY `email` (`email`);

--
-- Ευρετήρια για πίνακα `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`email`);

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `states`
--
ALTER TABLE `states`
  ADD CONSTRAINT `states_ibfk_1` FOREIGN KEY (`email`) REFERENCES `students` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
