<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="mystyle.css">
		<title> Myform </title>
	</head>
<body>
	<?php
	$email=$_POST['email'];
	include("conn.php");
	$sql = "SELECT `name` FROM `students` WHERE `email` = '".$email."';";
	$result = $conn->query($sql);
	$row=mysqli_fetch_assoc($result);
	?>
	<div align="center">
		<form method="post" action="insert.php">
			<h3>Hello, <?php echo $row['name'];?></h3>
			<h3>How do you feel today? <br>
				<input type="text" name="state" size="30">
				<input type="hidden" name="email" value ="<?php echo $email;?>">
			</h3>
			<h3>Why? <br> <textarea name="comments" cols="30" rows="1"></textarea></h3>
			<input type="submit" value="Send">
		</form>
	</div>
	<div align="Center">
		<h4>View states of <strong><?php echo $row['name'];?> </strong> </h4>
		<a href = "view1.php?email=<?php echo $email;?>">View 1</a> | 
		<a href = "view2.php?email=<?php echo $email;?>">View 2</a> | 
		<a href = "view3.php?email=<?php echo $email;?>">View 3</a>
	</div>
</body>
</html>